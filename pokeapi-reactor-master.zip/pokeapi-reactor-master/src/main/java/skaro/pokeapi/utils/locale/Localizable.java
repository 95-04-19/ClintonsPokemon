package skaro.pokeapi.utils.locale;

import java.util.List;

import skaro.pokeapi.resource.Name;

public interface Localizable {

	List<Name> getNames();
	
}
