package skaro.pokeapi.resource;

public interface PokeApiResource {

	Integer getId();
	String getName();
	
}
