package skaro.pokeapi.resource.growthrate;

public class GrowthRateExperienceLevel {

	private Integer level;
	private Integer experience;
	
	public Integer getLevel() {
		return level;
	}
	public void setLevel(Integer level) {
		this.level = level;
	}
	public Integer getExperience() {
		return experience;
	}
	public void setExperience(Integer experience) {
		this.experience = experience;
	}
	
}
